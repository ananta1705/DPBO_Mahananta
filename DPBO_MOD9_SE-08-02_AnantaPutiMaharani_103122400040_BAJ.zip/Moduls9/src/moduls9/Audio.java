/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moduls9;

/**
 *
 * @author ASUS
 */
// Audio.java
public class Audio extends Appliance {
    private String color;

    public Audio(String color) {
        this.color = color;
        setProduct("Audio");
    }
}
