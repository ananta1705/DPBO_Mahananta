/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pesion.biz;
/**
 *
 * @author ASUS
 */



import pension.AlreadyCheckoutException;
import pension.AlreadyReservedException;

public interface PensionBiz {
    void initializeRoomData();
    String checkIn(String roomId, String custName, String custPhone) throws AlreadyReservedException;
    String checkOut(String roomId) throws AlreadyCheckoutException;
    void roomList();
    // Metode helper untuk format uang bisa ditambahkan di sini atau di PensionBiz jika perlu
    // String moneyFormat(int amount);
}